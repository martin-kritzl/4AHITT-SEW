package test;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * Created by Martin Kritzl on 08.01.2015.
 */
public class test {

    @Test
    public void testCode() {
        assertEquals(true, true);
    }
}
